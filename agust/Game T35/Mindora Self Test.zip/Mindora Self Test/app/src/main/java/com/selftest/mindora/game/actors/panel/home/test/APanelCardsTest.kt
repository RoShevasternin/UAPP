package com.selftest.mindora.game.actors.panel.home.test

import com.selftest.mindora.game.actors.layout.autoLayout.AAutoLayout
import com.selftest.mindora.game.actors.test.card.ACardTest
import com.selftest.mindora.game.content.TestCatalog
import com.selftest.mindora.game.content.TestRepository
import com.selftest.mindora.game.utils.advanced.AdvancedScreen
import com.selftest.mindora.game.utils.gdxGame
import com.selftest.mindora.game.utils.runGDX
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

// ═════════════════════════════════════════════════════════════════════════════
//  APanelItemsTest — блок «Tests» на хабі: заголовок + 5 карток.
//
//  САМОСИНХРОНІЗУЄТЬСЯ. Підписаний на lumensFlow і testResultsFlow, тож
//  стани карток перераховуються самі: купив тест — картка стала «Open»,
//  пройшов — «Take Again», забрав дейлі й перетнув ціну — сіра стала жовтою.
//  Екрану не треба нічого «оновлювати» після повернення з теста.
//
//  ЧОМУ combine, А НЕ ДВА ОКРЕМІ collect: стан картки залежить від ОБОХ
//  джерел одночасно; два незалежні collect дали б проміжний кадр, де
//  баланс уже новий, а список пройдених ще старий.
// ═════════════════════════════════════════════════════════════════════════════
class APanelCardsTest(screen: AdvancedScreen) : AAutoLayout(
    screen     = screen,
    direction  = Direction.VERTICAL,
    gapMain    = 8f,
    sizingH    = Sizing.HUG,
    alignCross = AlignCross.CENTER,
) {

    // ------------------------------------------------------------------------
    // Actors
    // ------------------------------------------------------------------------
    private val cards = TestCatalog.ALL.map { ACardTest(screen) }

    // ------------------------------------------------------------------------
    // API
    // ------------------------------------------------------------------------
    /** Тап по кнопці картки. testId — рядковий id для TestRepository. */
    var onCardClick: (testId: String) -> Unit = {}

    // ------------------------------------------------------------------------
    // Lifecycle
    // ------------------------------------------------------------------------
    override fun addActorsOnGroup() {
        addCards()

        observeState()
    }

    // ------------------------------------------------------------------------
    // Add Actors
    // ------------------------------------------------------------------------
    private fun addCards() {
        cards.forEachIndexed { i, card ->
            card.setSize(ACardTest.W, ACardTest.H)
            add(card)

            val entry = TestCatalog.ALL[i]
            card.onClick = { onCardClick(entry.id) }
        }
    }

    // ------------------------------------------------------------------------
    // State
    // ------------------------------------------------------------------------
    private fun observeState() {
        val model = gdxGame.modelPlayer

        coroutine?.launch {
            combine(model.lumensFlow, model.testResultsFlow) { lumens, results -> lumens to results }
                .collect { (lumens, results) ->
                    runGDX { refresh(lumens, results.keys) }
                }
        }
    }

    private fun refresh(balance: Long, doneIds: Set<String>) {
        val costs = gdxGame.activity.appConfig.costs

        TestCatalog.ALL.forEachIndexed { i, entry ->
            val card  = cards[i]
            val price = costs.of(entry.testId)

            // TODO(purchase): окремого «куплено, ще не пройдено» у стані гравця
            //  поки немає — списання відбувається при старті теста, тож
            //  PURCHASED тут не виникає. Коли зʼявиться purchasedTestsFlow,
            //  міняється РІВНО цей рядок.
            val state = card.resolveState(
                isDone      = entry.id in doneIds,
                isPurchased = false,
                balance     = balance,
                price       = price,
            )

            card.bind(
                title     = TestRepository.get(entry.id).title,
                desc      = entry.subtitle,
                iconIndex = entry.index,
                price     = price,
                state     = state,
                animated  = true,
            )
        }
    }
}