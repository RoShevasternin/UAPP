package com.selftest.mindora.game.actors.portrait

import com.badlogic.gdx.graphics.Color
import com.badlogic.gdx.scenes.scene2d.Touchable
import com.badlogic.gdx.scenes.scene2d.ui.Image
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable
import com.badlogic.gdx.utils.Align
import com.selftest.mindora.game.actors.button.AMainButton
import com.selftest.mindora.game.actors.label.AMsdfLabel
import com.selftest.mindora.game.actors.layout.constraintLayout.AConstraintLayout
import com.selftest.mindora.game.actors.ui.ARoundRect
import com.selftest.mindora.game.content.TestRepository
import com.selftest.mindora.game.controller.PortraitController
import com.selftest.mindora.game.utils.Block
import com.selftest.mindora.game.utils.GameColor
import com.selftest.mindora.game.utils.actor.animHide
import com.selftest.mindora.game.utils.actor.animShow
import com.selftest.mindora.game.utils.advanced.AdvancedScreen
import com.selftest.mindora.game.utils.font.msdf.MsdfStyle
import com.selftest.mindora.game.utils.gdxGame

// ═════════════════════════════════════════════════════════════════════════════
//  APanelPortrait — верхній блок екрана «Your Portrait».
//
//   Unlock all 5 tests to unlock your portrait
//   ⬡ ⬡ ⬡ ⬡ ⬡          ← 5 іконок: кольорова = тест пройдено
//   [ портрет із замком ]
//   ( Unlock My Portrait )
//
//  ПІСЛЯ СИНТЕЗУ той самий блок показує назву і таглайн портрета замість
//  замка і кнопки — окремого екрана під це немає, і не треба: людина
//  приходить сюди дивитись саме на портрет.
//
//  ІКОНКИ беруться з listIcEna / listIcDis по позиції теста в
//  TestRepository.ALL — та сама пара, що на картках тестів, тож нової мапи
//  не заводимо.
// ═════════════════════════════════════════════════════════════════════════════
class APanelPortrait(override val screen: AdvancedScreen) : AConstraintLayout(screen) {

    companion object {
        const val W = 344f
        const val H = 420f

        private const val ICON     = 34f
        private const val ART_H    = 250f
        private const val BTN_H    = 56f
    }

    // ------------------------------------------------------------------------
    // Font
    // ------------------------------------------------------------------------
    private val msdf = gdxGame.msdfManager

    private val styleHint    = MsdfStyle(msdf, msdf.fontMontserrat_Regular, 12f, GameColor.white_80)
    private val styleName    = MsdfStyle(msdf, msdf.fontMontserrat_Medium, 24f, Color.WHITE)
    private val styleTagline = MsdfStyle(msdf, msdf.fontMontserrat_Italic, 13f, GameColor.yellow_FFD98A)

    // ------------------------------------------------------------------------
    // Actors
    // ------------------------------------------------------------------------
    private val aBgImg    = Image(gdxGame.assetsAll.panel_result)
    private val aHintLbl  = AMsdfLabel("Unlock all 5 tests to unlock your portrait", styleHint)

    private val aIcons = List(TestRepository.ALL.size) { Image() }

    // TODO(art): арт портрета. Поки плашка з замком по центру.
    private val aArtImg   = ARoundRect(screen)
    private val aLockImg  = Image(gdxGame.assetsAll.lock)

    private val aNameLbl    = AMsdfLabel("", styleName)
    private val aTaglineLbl = AMsdfLabel("", styleTagline)
    private val aUnlockBtn  = AMainButton(screen, "Unlock My Portrait")

    // ------------------------------------------------------------------------
    // API
    // ------------------------------------------------------------------------
    var onUnlock: Block = {}

    // ------------------------------------------------------------------------
    // Lifecycle
    // ------------------------------------------------------------------------
    override fun addActorsOnGroup() {
        add(aBgImg) { fillParent() }

        aHintLbl.setSize(W - 32f, 32f)
        add(aHintLbl) { centerX(); topToTop(margin = 16f) }
        aHintLbl.setAlignment(Align.center)
        aHintLbl.setWrap(true)

        addIcons()
        addArt()

        aNameLbl.setSize(W - 32f, 30f)
        add(aNameLbl) { centerX(); bottomToBottom(margin = 60f) }
        aNameLbl.setAlignment(Align.center)

        aTaglineLbl.setSize(W - 32f, 18f)
        add(aTaglineLbl) { centerX(); bottomToBottom(margin = 38f) }
        aTaglineLbl.setAlignment(Align.center)

        aUnlockBtn.setSize(310f, BTN_H)
        add(aUnlockBtn) { centerX(); bottomToBottom(margin = 20f) }
        // AButtonBase має ВЛАСНИЙ setOnClickListener(sound, block) — без
        // stopEvent. Він і не потрібен: кнопка не гасить подію, а від
        // випадкових спрацювань при скролі захищає своїм scrollThreshold.
        aUnlockBtn.setOnClickListener { onUnlock() }
    }

    private fun addIcons() {
        val gap = (W - 64f - aIcons.size * ICON) / (aIcons.size - 1).coerceAtLeast(1)

        aIcons.forEachIndexed { i, img ->
            img.setSize(ICON, ICON)
            add(img) { startToStart(margin = 32f + i * (ICON + gap)); topToTop(margin = 56f) }
        }
    }

    private fun addArt() {
        aArtImg.radius      = 16f
        aArtImg.color       = GameColor.purple_9979FF.cpy()
        aArtImg.fillAlpha   = 0.25f
        aArtImg.strokeWidth = 0f
        aArtImg.setSize(W - 32f, ART_H)
        add(aArtImg) { centerX(); topToTop(margin = 100f) }

        aLockImg.setSize(46f, 58f)
        add(aLockImg) { centerX(); topToTop(margin = 100f + ART_H / 2f - 29f) }
    }

    // ------------------------------------------------------------------------
    // API
    // ------------------------------------------------------------------------
    fun render(state: PortraitController.State, animated: Boolean = true) {
        val t = if (animated) 0.2f else 0f

        // Іконки: кольорова = вимір відкритий. Порядок cards зі стану збігається
        // з TestRepository.ALL, тож індекс і є індексом іконки.
        state.cards.forEachIndexed { i, card ->
            if (i >= aIcons.size) return@forEachIndexed
            val region = if (card.done) gdxGame.assetsAll.listIcEna[i] else gdxGame.assetsAll.listIcDis[i]
            aIcons[i].drawable = TextureRegionDrawable(region)
        }

        val synth = state.synthesis

        if (synth != null) {
            // Портрет уже зібраний — замок і кнопка більше не потрібні.
            aLockImg.animHide(t)
            aUnlockBtn.animHide(t)
            aUnlockBtn.touchable = Touchable.disabled

            aNameLbl.setText(synth.name)
            aTaglineLbl.setText(synth.tagline)
            aNameLbl.animShow(t)
            aTaglineLbl.animShow(t)

            aHintLbl.setText("Your portrait is complete")
        } else {
            aLockImg.animShow(t)
            aNameLbl.animHide(t)
            aTaglineLbl.animHide(t)

            aUnlockBtn.animShow(t)
            // Кнопка активна тільки коли поріг узято — інакше вона обіцяє те,
            // чого ще немає. Стан бере контролер, панель лише малює.
            aUnlockBtn.touchable =
                if (state.canSynthesize) Touchable.enabled
                else Touchable.disabled
            aUnlockBtn.color.a = if (state.canSynthesize) 1f else 0.5f

            aHintLbl.setText(
                "Unlock all ${state.totalCount} tests to unlock your portrait"
            )
        }
    }
}