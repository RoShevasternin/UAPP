package com.selftest.mindora.game.screens

import com.badlogic.gdx.scenes.scene2d.ui.Image
import com.selftest.mindora.game.actors.panel.APanelTopHome
import com.selftest.mindora.game.actors.debug.ADebugHud
import com.selftest.mindora.game.actors.debug.addDebugHud
import com.selftest.mindora.game.actors.layout.constraintLayout.AConstraintLayout
import com.selftest.mindora.game.actors.panel.home.APanelHome
import com.selftest.mindora.game.actors.panel.home.main.APanelItemsMain
import com.selftest.mindora.game.actors.panel.home.test.APanelItemsTest
import com.selftest.mindora.game.actors.popup.APopup
import com.selftest.mindora.game.actors.popup.APopupMore
import com.selftest.mindora.game.actors.popup.APopupStart
import com.selftest.mindora.game.content.TestRepository
import com.selftest.mindora.game.screens.TestScreen
import com.selftest.mindora.game.utils.Block
import com.selftest.mindora.game.utils.GameColor
import com.selftest.mindora.game.utils.TIME_ANIM_SCREEN
import com.selftest.mindora.game.utils.VERTICAL_BIAS
import com.selftest.mindora.game.utils.actor.animHide
import com.selftest.mindora.game.utils.actor.animHideAndDisable
import com.selftest.mindora.game.utils.actor.animShow
import com.selftest.mindora.game.utils.actor.animShowAndEnable
import com.selftest.mindora.game.utils.actor.setOnClickListener
import com.selftest.mindora.game.utils.advanced.AdvancedScreen
import com.selftest.mindora.game.utils.gdxGame
import com.selftest.mindora.game.utils.overlay.OverlayManager
import kotlin.getValue

class MenuScreen : AdvancedScreen() {

    // ------------------------------------------------------------------------
    // Overlay
    // ------------------------------------------------------------------------
    private enum class Overlay { POPUP_START, POPUP_MORE, POPUP,  }

    private val overlayManager = OverlayManager(
        onShowDim = { aDimImg.animShowAndEnable(timeShow) },
        onHideDim = { aDimImg.animHideAndDisable(timeHide) },
    )

    // ------------------------------------------------------------------------
    // Field
    // ------------------------------------------------------------------------
    private val timeShow = 0.2f
    private val timeHide = 0.2f

    // ------------------------------------------------------------------------
    // Actors
    // ------------------------------------------------------------------------
    private val aDimImg      by lazy { Image(drawerUtil.getTexture(GameColor.black_0A001D_80)) }
    private val aPopupStart  by lazy { APopupStart(this) }
    private val aPopup       by lazy { APopup(this) }
    private val aPopupMore   by lazy { APopupMore(this) }

    private val aPanelTopHome by lazy { APanelTopHome(this) }
    private val aPanelHome    by lazy { APanelHome(this) }

    private val aPanelItemsMain by lazy { APanelItemsMain(this) }
    private val aPanelItemsTest by lazy { APanelItemsTest(this) }

    // ------------------------------------------------------------------------
    // Lifecycle
    // ------------------------------------------------------------------------
    override fun show() {
        rootConstraintLayout.color.a = 0f
        setBackground(gdxGame.assetsLoader.BACKGROUND)

        super.show()
        animShowScreen()

        gdxGame.analytics.openHomeScreen()
    }

    // ------------------------------------------------------------------------
    // Screen Animations
    // ------------------------------------------------------------------------
    override fun animHideScreen(blockEnd: Block) {
        rootConstraintLayout.animHide(TIME_ANIM_SCREEN) { blockEnd() }
    }

    override fun animShowScreen(blockEnd: Block) {
        rootConstraintLayout.animShow(TIME_ANIM_SCREEN) { blockEnd() }
    }

    // ------------------------------------------------------------------------
    // Add Actors
    // ------------------------------------------------------------------------
    override fun AConstraintLayout.addActorsOnRootConstraintLayout() {
        addPanelTopHome()
        addPanelHome()

        addDimImg()
        if (gdxGame.modelPlayer.getIsFirstOpen()) {
            gdxGame.modelPlayer.setIsFirstOpen(false)
            addPopupStart()
            overlayManager.show(Overlay.POPUP_START)
        }
        addPopup()
        addPopupMore()

        addDebugHud(ADebugHud(this@MenuScreen))
    }

    // ------------------------------------------------------------------------
    // Add Actors - Panel
    // ------------------------------------------------------------------------
    private fun AConstraintLayout.addPanelTopHome() {
        aPanelTopHome.setSize(344f, 48f)
        add(aPanelTopHome) { centerX(); topToTop(margin = 8f) }

        aPanelTopHome.onPanelRBX = { overlayManager.show(Overlay.POPUP_MORE) }
    }

    private fun AConstraintLayout.addPanelHome() {
        aPanelHome.width = 344f
        add(aPanelHome) { centerX(); topToBottom(aPanelTopHome, 24f); bottomToBottom(); matchHeight() }

        aPanelHome.apply {
            addPanelItemsMain()
            addPanelItemsTest()
        }
    }

    // ------------------------------------------------------------------------
    // Add Actors - Items
    // ------------------------------------------------------------------------
    private fun APanelHome.addPanelItemsMain() {
        aPanelItemsMain.setSize(344f, 1f)
        addItem(aPanelItemsMain)

        aPanelItemsMain.aPanelItemDaily.onClaim = {
            animHideScreen {
                gdxGame.navigationManager.navigate(DailyScreen::class.java.name, MenuScreen::class.java.name)
            }
        }

        // ── ТИМЧАСОВО, до появи екрана списку тестів ─────────────────────────
        // Тап по картці портрета відкриває ПЕРШИЙ ще не пройдений тест
        // (порядок = TestRepository.ALL). Коли з'явиться Tests-екран за
        // макетом — цей блок переїде туди, ключ передається так само.
        aPanelItemsMain.aPanelItemPortrait.setOnClickListener {
            val passed = gdxGame.modelPlayer.testResults().keys
            val nextId = TestRepository.ALL.firstOrNull { it !in passed } ?: TestRepository.ALL.first()
            animHideScreen {
                gdxGame.navigationManager.navigate(
                    TestScreen::class.java.name,
                    MenuScreen::class.java.name,
                    key = TestRepository.ALL.indexOf(nextId),
                )
            }
        }
    }

    private fun APanelHome.addPanelItemsTest() {
        aPanelItemsTest.setSize(344f, 1f)
        addItem(aPanelItemsTest)

//        aPanelItemsTest.aPanelCardsTest.onClaim = {
//            animHideScreen {
//                gdxGame.navigationManager.navigate(DailyScreen::class.java.name, MenuScreen::class.java.name)
//            }
//        }
    }

    // ------------------------------------------------------------------------
    // Add Actors - Dim | Popup
    // ------------------------------------------------------------------------
    private fun AConstraintLayout.addDimImg() {
        aDimImg.animHideAndDisable()
        add(aDimImg) {
            matchConstraint()
            centerX(); bottomToBottom(); topToTop(margin = -safeStatusBarUI)
        }
        aDimImg.setOnClickListener(null) {
            if (overlayManager.isClosable) overlayManager.close()
        }
    }

    private fun AConstraintLayout.addPopupStart() {
        aPopupStart.animHideAndDisable()
        aPopupStart.setSize(362f, 443f)
        add(aPopupStart) { center(); verticalBias = VERTICAL_BIAS }

        overlayManager.register(
            Overlay.POPUP_START, OverlayManager.Config(
                showDim    = true,
                isClosable = false, // поки не забрав нагороду — не закривати кліком по фону
                onShow     = { aPopupStart.animShowAndEnable(timeShow) },
                onHide     = { aPopupStart.animHideAndDisable(timeHide) },
            ))

        aPopupStart.onStart = { overlayManager.close() }
    }

    private fun AConstraintLayout.addPopup() {
        aPopup.animHideAndDisable()
        aPopup.setSize(362f, 401f)
        add(aPopup) { center(); verticalBias = VERTICAL_BIAS }

        overlayManager.register(
            Overlay.POPUP, OverlayManager.Config(
                showDim    = true,
                isClosable = false, // поки не забрав нагороду — не закривати кліком по фону
                onShow     = { aPopup.animShowAndEnable(timeShow) },
                onHide     = { aPopup.animHideAndDisable(timeHide) },
            ))

        aPopup.onClaim = { overlayManager.close() }
    }

    private fun AConstraintLayout.addPopupMore() {
        aPopupMore.animHideAndDisable()
        aPopupMore.setSize(362f, 376f)
        add(aPopupMore) { center(); verticalBias = VERTICAL_BIAS }

        overlayManager.register(
            Overlay.POPUP_MORE, OverlayManager.Config(
                showDim    = true,
                isClosable = true,
                onShow     = { aPopupMore.animShowAndEnable(timeShow) },
                onHide     = { aPopupMore.animHideAndDisable(timeHide) },
            ))

        aPopupMore.onWatch = { reward ->
            aPopup.setReward(reward)
            overlayManager.close()
            gdxGame.activity.showInterstitial { overlayManager.show(Overlay.POPUP) }
        }
    }

}