//package com.rbxhubpro.rohumex.game.model
//
//import com.rbxhubpro.rohumex.game.data.PlayerData
//import com.rbxhubpro.rohumex.game.dataStore.DS_Player
//import kotlinx.coroutines.CoroutineScope
//import kotlinx.coroutines.flow.*
//import kotlin.math.ln
//import kotlin.math.pow
//
//class PlayerModel(
//    private val ds: DS_Player,
//    scope: CoroutineScope
//) {
//
//    // =====================================================
//    // Джерело правди
//    // =====================================================
//
//    val playerFlow: StateFlow<PlayerData> =
//        ds.flow.stateIn(
//            scope = scope,
//            started = SharingStarted.Eagerly,
//            initialValue = ds.flow.value
//        )
//
//    val currentPlayer: PlayerData
//        get() = playerFlow.value
//
//}
